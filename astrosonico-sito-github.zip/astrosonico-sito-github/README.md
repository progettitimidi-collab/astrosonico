# ASTROSONICO — Sito HTML pronto per GitHub Pages

## Che cosa contiene

Cinque pagine complete, responsive e senza framework:

- `index.html` — homepage, orientamento, servizi principali, Francesca, Business, ritiri e FAQ.
- `sessioni.html` — Tema Natale, Tarocchi, Transiti personali, Roadmap annuale e Sinastria.
- `astro-for-business.html` — percorso annuale, struttura di 13 incontri e prezzi attuali.
- `gift-card.html` — importi e collegamento all'acquisto Wix.
- `ritiri.html` — RADICI 18–20 dicembre 2026, ANCESTRALE e A PER ASTRO.
- `assets/css/style.css` — tutti colori, font, componenti e layout responsive.
- `assets/js/site.js` — menu mobile; nessun tracking, nessuna raccolta dati.
- `assets/img/astrosonico-mark.svg` — icona grafica.
- `scarica-foto.py` — utility facoltativa per copiare le foto Wix nel progetto.
- `.nojekyll` — facilita la pubblicazione statica su GitHub Pages.

Nessun pacchetto software necessario: **apri `index.html`** nel browser per vedere il sito, mantenendo intatte le cartelle.

## Pubblicazione semplice su GitHub Pages

1. Crea un account o accedi su `github.com`.
2. Clicca `New repository` e chiamalo, ad esempio, `astrosonico`. Scegli **Public** se usi GitHub Free.
3. Estrai **tutti** i file dello ZIP sul computer.
4. Nel repository, vai su `Add file → Upload files` (o pulsante `+` equivalente) e trascina tutti i file e le cartelle estratte. **Non caricare solo lo ZIP**. `index.html` deve trovarsi alla radice del repository, non dentro una cartella aggiuntiva.
5. Clicca `Commit changes`.
6. Vai su `Settings → Pages` e scegli `Build and deployment → Source: Deploy from a branch`, poi `main` e `/(root)`, e `Save`.
7. L'indirizzo standard del sito sarà `https://NOMEUTENTE.github.io/astrosonico/` (con il tuo username e il nome del repository). Il primo caricamento richiede la pubblicazione di GitHub Pages.
8. Per modificare testi o link: apri il file `.html` relativo, clicca sulla matita `Edit`, modifica e fai `Commit changes`. Per i colori modifica `assets/css/style.css`, nella sezione iniziale `:root`.

Guida ufficiale: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

## Foto provenienti da Wix

Le immagini usate qui sono **richiamate con URL pubblici Wix**; al momento **non sono state copiate fisicamente dentro lo ZIP**. Questa soluzione permette una prima visualizzazione sul web, ma per il sito definitivo è più robusto ospitare le foto nella cartella `assets/img/` del repository. La loro disponibilità dipende anche dal CDN Wix.

Per renderle locali: se il computer dispone di Python 3, con Internet attivo esegui dalla cartella del progetto:

```bash
python3 scarica-foto.py
```

Lo script prova a scaricare sette fotografie dai link delle pagine Wix e sostituisce negli HTML i percorsi remoti con quelli locali **solo quando il download riesce**. In caso di errore lascia il collegamento originale. Prima di pubblicare verifica per ciascuna foto qualità, soggetto, orientamento e diritti d'uso. Si consiglia di scegliere dalla propria libreria Wix gli originali migliori, specie per il ritratto di Francesca.

## Prenotazioni, pagamenti e contatti

GitHub Pages è un hosting **statico**: non gestisce nativamente calendari, checkout, pagamenti, database né invio di form. Per non simulare funzionalità inesistenti:

- le prenotazioni individuali aprono le pagine Wix corrispondenti;
- le Gift Card aprono lo shop Gift Card su Wix;
- RADICI / A PER ASTRO aprono le pagine Wix;
- Astro for Business e i contatti sono richieste via email a `cibosupersonico@gmail.com`.

I link sono già inseriti negli HTML. L'apertura di Wix in una nuova scheda è intenzionale. In seguito si può integrare un checkout Stripe o un servizio esterno, ma richiede configurazione separata.

## Verifiche commerciali prima del lancio

1. **Astro for Business**: Wix mostra tariffa ordinaria 1.800 € e promozione lancio 1.450 €. Il sito conserva entrambe ma, in vista del 2027, occorre decidere se la promozione sarà ancora valida. Il percorso descritto comprende 13 incontri in 12 mesi.
2. **RADICI**: il 18–20 dicembre 2026 è una data reale pubblicata sul sito attuale. La sede (Miri Piri), il prezzo (480 €), le condizioni (240 € di acconto) e il pulsante vanno riconfermati se cambia la location o la disponibilità.
3. **ANCESTRALE**: pagina eventi con appuntamento del 31 ottobre 2026. Va aggiornato o rimosso dopo quella data per evitare servizi scaduti.
4. **Tariffe e condizioni**: verificare importi e policy di cancellazione con le pagine Wix prima di promuovere il nuovo dominio.
5. **Privacy e informazioni legali**: inserire nel nuovo sito link corretti e aggiornati a privacy policy, note legali e condizioni d'acquisto. Il footer contiene P.IVA e contatto ma non è, da solo, una policy completa.
6. **Foto, accessibilità e dispositivi**: controllare le immagini originali (fino a 150–300 kB se possibile), prova su iPhone/Android, alt testuali, contrasto e revisione refusi.
7. **SEO**: una volta deciso il dominio, aggiungere `canonical`, `og:url`, sitemap XML e Google Search Console. Per non indicizzare due siti concorrenti con lo stesso contenuto, decidere se il vecchio sito resterà come booking o reindirizzerà le vecchie pagine.

## Dominio personalizzato

È possibile collegare, ad esempio, `astrosonico.it` oppure `astro.cibosupersonico.com`.

1. In `Settings → Pages → Custom domain`, inserisci il dominio scelto e salva.
2. Nel pannello DNS del dominio configura i record richiesti dal tipo di dominio. Per un **sottodominio**, in genere un `CNAME` verso `NOMEUTENTE.github.io` (non verso la cartella del repository). Non modificare il DNS del sito principale senza analizzare gli effetti su Wix.
3. Attiva `Enforce HTTPS` appena disponibile.

Guida ufficiale: https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site/managing-a-custom-domain-for-your-github-pages-site

## Posizionamento scelto

- **Home**: promessa semplice e non deterministica ("Il cielo è una mappa. Non una sentenza."). È comprensibile anche a chi non conosce astrologia e tarologia.
- **Sessioni**: decisione per bisogno e prezzo, senza obbligare a leggere spiegazioni lunghe prima di trovare il servizio.
- **Astro for Business**: pagina autonoma e prioritaria, per permettere campagne e traffico dedicati nel 2027. È un percorso simbolico e di consapevolezza personale, **non** una consulenza finanziaria o di marketing.
- **Gift Card**: esperienza regalo distinta da un catalogo di servizi.
- **Ritiri**: identità esperienziale, logisticamente chiara, distinta dagli appuntamenti individuali online.

Palette: rosa cipria, bianco caldo, lilla, cielo pallido, testo antracite. Titoli serif editoriali, testi sans serif leggibili. Niente dipendenze software, cookie analytics, moduli finti o animazioni invasive.
