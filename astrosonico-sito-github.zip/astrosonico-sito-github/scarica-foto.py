#!/usr/bin/env python3
"""Scarica i media Wix indicati dagli HTML nel progetto AstroSonico.
   Uso facoltativo: python3 scarica-foto.py
   Richiede internet, non installa librerie.
"""
from pathlib import Path
import urllib.request

BASE=Path(__file__).resolve().parent
ASSETS=BASE/'assets'/'img'
ASSETS.mkdir(parents=True,exist_ok=True)
IMAGES={
 'francesca.jpg':'436eaf_81b6aed6b3834a8282c489338c41504a~mv2.jpg',
 'ritiro-1.jpg':'436eaf_80eecdb5b0624e5ea358e48437302117~mv2.jpg',
 'ritiro-2.jpg':'436eaf_d5dd457602154fdfa00543d83fc7b517~mv2.jpg',
 'ritiro-3.jpg':'436eaf_8ea00984b81c49c587607b10d771116e~mv2.jpg',
 'fasi-lunari.jpg':'436eaf_a2a7fb364a7c42b4806ceaa7ba67449f~mv2.jpg',
 'ritiro-ibiza.jpg':'436eaf_b5af1461f77d415e90dafcff3867ca3b~mv2.jpg',
 'business.png':'436eaf_7e86ae28d1464c0fb291b1b2eedbd687~mv2.png',
}
for name,remote_file in IMAGES.items():
 url='https://static.wixstatic.com/media/'+remote_file
 output=ASSETS/name
 if not output.exists():
  try:
   req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (compatible; AstroSonico content migration)'})
   with urllib.request.urlopen(req,timeout=20) as response:
    content=response.read()
    typ=response.headers.get('Content-Type','')
   if len(content)<1500 or 'image' not in typ.lower():raise ValueError(f'Risposta non valida: {typ}, {len(content)} byte')
   output.write_bytes(content)
   print('OK',name,len(content),'byte')
  except Exception as ex:
   print('NON SCARICATA:',name,ex)
 if output.exists():
  for path in BASE.glob('*.html'):
   old=path.read_text(encoding='utf-8')
   new=old.replace(url,'assets/img/'+name)
   if old!=new:path.write_text(new,encoding='utf-8')
print('Concluso. Verifica che tutte le immagini siano quelle desiderate.')
