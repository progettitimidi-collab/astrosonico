/* Solo interazioni locali: niente cookie, tracciamento o server. */
(()=>{
 const btn=document.querySelector('.menu-toggle');
 const menu=document.querySelector('.mobile-nav');
 if(btn&&menu){const close=()=>{menu.classList.remove('is-open');btn.setAttribute('aria-expanded','false');btn.setAttribute('aria-label','Apri menu')};btn.addEventListener('click',()=>{const isOpen=menu.classList.toggle('is-open');btn.setAttribute('aria-expanded',String(isOpen));btn.setAttribute('aria-label',isOpen?'Chiudi menu':'Apri menu')});menu.querySelectorAll('a').forEach(a=>a.addEventListener('click',close));document.addEventListener('keydown',e=>{if(e.key==='Escape')close()});}
 document.querySelectorAll('[data-year]').forEach(el=>el.textContent=String(new Date().getFullYear()));
})();
